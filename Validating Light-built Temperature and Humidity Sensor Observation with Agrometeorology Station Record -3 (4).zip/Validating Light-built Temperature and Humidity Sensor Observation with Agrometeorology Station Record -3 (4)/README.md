# Thesis Template

Usage
To run these files, here are the options to use;

- A collaborative cloud based LaTex editor called **Overleaf**
- An integrated writing environment called **TeXstudio**
